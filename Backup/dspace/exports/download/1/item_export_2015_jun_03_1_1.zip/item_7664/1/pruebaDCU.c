

//escribo un programita sencillo porque solo es para una prueba
#include <stdio.h>
 
int main()
{
  printf("Hello world\n");
  return 0;
}
